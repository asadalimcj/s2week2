﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace challenge1
{
    class Program
    {
        static void Main(string[] args)
        {
            StoreManagement[] store = new StoreManagement[10];
            char choice;
            int count = 0;
            do
            {
                choice = menu();
                if (choice == '1')
                {
                    store[count] = AddProducts();
                    count = count + 1;
                }
                else if (choice == '2')
                {
                    ViewProduct(store, count);
                }
                else if (choice == '3')
                {
                    float total = NetWorth(store, count);
                    Console.WriteLine("total revenue is :{0}", total);
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("wrong choice:");
                }
            }
            while (choice != '4');
            Console.WriteLine("enter a key to exit:");
            Console.ReadKey();
        }
        static char menu()
        {
            char choice;
            Console.WriteLine("1.Add Products:");
            Console.WriteLine("2.Show Products:");
            Console.WriteLine("3.Net Worth:");
            Console.WriteLine("4.EXIT:");
            Console.WriteLine("enter your choice:");
            choice = char.Parse(Console.ReadLine());
            return choice;
        }
        static StoreManagement AddProducts()
        {
            Console.Clear();
            StoreManagement store = new StoreManagement();
            Console.WriteLine("enter product ID:");
            store.P_ID = Console.ReadLine();
            Console.WriteLine("enter product name:");
            store.p_name = Console.ReadLine();
            Console.WriteLine("enter product price:");
            store.p_price = float.Parse(Console.ReadLine());
            Console.WriteLine("enter product categaory:");
            store.Category = Console.ReadLine();
            Console.WriteLine("enter product brand:");
            store.BrandName = Console.ReadLine();
            Console.WriteLine("enter country:");
            store.country = Console.ReadLine();
            return store;
        }
        static void ViewProduct(StoreManagement[] store, int counter)
        {
            Console.Clear();
            for(int idx = 0; idx<counter; idx++)
            {
                Console.WriteLine("product ID : {0}  product name: {1}  product price: {2}  product category: {3}  brand name: {4}, country: {5}", store[idx].P_ID, store[idx].p_name, store[idx].p_price, store[idx].Category, store[idx].BrandName, store[idx].country);
            }
            Console.WriteLine("enter a key:");
            Console.ReadKey();
        }
        static float NetWorth(StoreManagement[] store, int count)
        {
            float sum = 0;
            for(int idx = 0; idx<count; idx++)
            {
                sum = sum + store[idx].p_price;
            }
            return sum;
        }
    }
}
