﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace challenge1
{
    public class StoreManagement
    {
        public string P_ID;
        public string p_name;
        public float p_price;
        public string Category;
        public string BrandName;
        public string country;
    }
}
