﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace challenge2
{
    class Program
    {
        static void Main(string[] args)
        {
            login[] store = new login[5];
            int count = 0;
            int choice = 0;
            string path = "D:\\uetlahore\\semester2\\OOP\\labs\\week2lab\\challenge2\\log.txt";
            ReadFromFile(path, store);
            while(choice!=3)
            {
                Console.Clear();
                choice = Menu();
                if(choice==1)
                {
                    Console.WriteLine("enter name:");
                    string n = Console.ReadLine();
                    Console.WriteLine("enter password:");
                    int pass = int.Parse(Console.ReadLine());
                    store[count]=SignUp(n, pass);
                    count = count + 1;
                    storeInfoInfile(path, store, count);
                }
                else if (choice== 2)
                {
                    Console.WriteLine("enter name:");
                    string n = Console.ReadLine();
                    Console.WriteLine("enter passwod:");
                    int pas = int.Parse(Console.ReadLine());
                    bool log = signIn(n, pas, store, count);
                    if(log == true)
                    {
                        Console.WriteLine("succefully");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("not found");
                        Console.ReadKey();
                    }
                }
            }
        }
        static int Menu()
        {
            int number;
            Console.WriteLine("1: signUp");
            Console.WriteLine("2: lognIn");
            Console.WriteLine("3: Exit");
            Console.WriteLine("enter your choice:");
            number = int.Parse(Console.ReadLine());
            return number;
        }
        static login SignUp(string name, int pass)
        {
            Console.Clear();
            login store = new login();
            store.username = name;
            store.password = pass;
            return store;
        }
        static bool signIn(string name, int pass, login[] store, int count)
        {
            bool flag = false;
            for (int idx = 0; idx < count; idx++)
            {
                if (name == store[idx].username && pass == store[idx].password)
                {
                    flag = true;
                }
            }
            return flag;
        }
        static void storeInfoInfile(string path, login[] store, int count)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(store[count].username + "," + store[count].password);
            file.Flush();
            file.Close();
        }
        static void ReadFromFile(string path, login[] store)
        {
            int x = 0;
            if(File.Exists(path))
            {
                StreamReader file = new StreamReader(path, true);
                string record;
                while((record = file.ReadLine())!= null)
                {
                    login store1 = new login();
                    store1.username = parseData(record, 1);
                    Console.WriteLine(parseData(record,1) + parseData(record, 2));
                    Console.ReadKey();
                    store1.password = int.Parse(parseData(record, 2));
                    store[x]= store1;
                    x++;
                }
                file.Close();
            }
            else
            {
                Console.WriteLine("no record");
            }
        }
        static string parseData(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int idx = 0; idx < record.Length; idx++)
            {
                if (record[idx] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[idx];
                }
            }
            return item;
        }
    }
}
