﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace challenge2
{
    public class login
    {
        public string username;
        public int password;
    }
}
