﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2task1
{
    class Program
    {
        class  student
        {
           public string name;
            public int roll_NO;
           public float aggregate;
        }
        static void Main(string[] args)
        {
            //task1();
            //task2();
            //task3();
            studentManagement[] s = new studentManagement[10];
            char choice;
            int count = 0;
            do
            {
                choice = task4Menu();
                if(choice == '1')
                {
                    s[count] = addstudent();
                    count = count+1;
                }
                else if(choice =='2')
                {
                    viewStudent(s, count);
                }
                else if(choice =='3')
                {
                    TopStudent(s, count);
                }
                else if(choice == '4')
                {
                    break;
                }
                else
                {
                    Console.WriteLine("wrong option");
                }
            }
            while (choice != '4');
            Console.WriteLine("press a key to exit");
            Console.ReadLine();
        }
        static void task1()
        {
            student S1 = new student();
            S1.name = "asad ali";
            S1.roll_NO = 185;
            S1.aggregate = 67.5F;
            Console.WriteLine("name: {0}  Roll no :{1}  aggregatte: {2}", S1.name, S1.roll_NO, S1.aggregate);
            Console.ReadKey();
        }
        static void task2()
        {
            student S2 = new student();
            S2.name = "Anas ali";
            S2.roll_NO = 185;
            S2.aggregate = 87.9F;
            Console.WriteLine("Namë:{0}: Roll no:{1}: aggregate: {2}", S2.name, S2.roll_NO, S2.aggregate);
            Console.ReadKey();
        }
        static void task3()
        {
            student S3 = new student();
            Console.WriteLine("enter name:");
            S3.name = Console.ReadLine();
            Console.WriteLine("enter roll number:");
            S3.roll_NO = int.Parse(Console.ReadLine());
            Console.WriteLine("enter your aggregate:");
            S3.aggregate = float.Parse(Console.ReadLine());
            Console.WriteLine("name :{0}  roll no: {1}  aggregate:  {3}", S3.name, S3.roll_NO, S3.aggregate);
            Console.Read();
        }
        static char task4Menu()
        {
            char choice;
            Console.WriteLine("1. adding a student:");
            Console.WriteLine("2. view students:");
            Console.WriteLine("3. top three student:");
            Console.WriteLine("4. exit:");
            Console.WriteLine("enter your choice:");
            choice = char.Parse(Console.ReadLine());
            return choice;
        }
        static studentManagement addstudent()
        {
            Console.Clear();
            studentManagement S4 = new studentManagement();
            Console.WriteLine("enter your name:");
            S4.name = Console.ReadLine();
            Console.WriteLine("enter your roll number:");
            S4.roll_no = int.Parse(Console.ReadLine());
            Console.WriteLine("enter your cgpa:");
            S4.cgpa = float.Parse(Console.ReadLine());
            Console.WriteLine("is hostelide (y || n)");
            S4.isHostelide = char.Parse(Console.ReadLine());
            Console.WriteLine("enter your department:");
            S4.department = Console.ReadLine();
            return S4;
        }
        static void viewStudent(studentManagement[] s, int count)
        {
            Console.Clear();
            for(int idx = 0; idx<count; idx++)
            {
                Console.WriteLine("namë: {0}  roll number:  {1}  cgpa:  {2}  is hostelide:  {3}  department:  {4}", s[idx].name, s[idx].roll_no,s[idx].cgpa, s[idx].isHostelide, s[idx].department);

            }
            Console.WriteLine("press a key:");
            Console.ReadKey();
        }
        static void TopStudent(studentManagement[] s, int count)
        {
            Console.Clear();
            if(count == 0)
            {
                Console.WriteLine("no record found:");
                Console.WriteLine("press a key:");
                Console.ReadKey();
            }
            else if(count ==1)
            {
                viewStudent(s, 1);
            }
            else if (count==2)
            {
                for(int idx = 0; idx<2; idx++)
                {
                    int index = largest(s, idx, count);
                    studentManagement temp = s[index];
                    s[index] = s[idx];
                    s[idx] = temp;
                }
                viewStudent(s, 2);
            }
            else
            {
                for(int idx = 0; idx<3; idx++)
                {
                    int index = largest(s, idx, count);
                    studentManagement temp = s[index];
                    s[index] = s[idx];
                    s[idx] = temp;
                }
                viewStudent(s, 3);
            }
        }
        static int largest(studentManagement[] s, int start, int end)
        {
            int index = start;
            float large = s[start].cgpa;
            for(int idx = start; idx<end; idx++)
            {
                if(large<s[idx].cgpa)
                {
                    large = s[idx].cgpa;
                    index = idx;
                }
            }
            return index;
        }
    }
}
