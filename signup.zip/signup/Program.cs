﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace signup
{
    class Program
    {
        static void Main(string[] args)
        {
            List<log> user = new List<log>();
            string path = "D:\\uetlahore\\semester2\\OOP\\labs\\week2lab\\signup\\path.txt";
            int choice = 0;
            while(choice !=3)
            {
                ReadData(path, user);
                Console.Clear();
                choice = menu();
                if(choice == 1)
                {
                    Console.WriteLine("enter your name:");
                    string name = Console.ReadLine();
                    Console.WriteLine("enter your passsword:");
                    string pass = Console.ReadLine();
                    signup(path, name, pass);
                }
                else if(choice ==2)
                {
                    Console.WriteLine("enter your name:");
                    string n = Console.ReadLine();
                    Console.WriteLine("enter password:");
                    string p = Console.ReadLine();
                    signIn(n, p, user);
                }
                else
                {
                    break;
                }
            }
        }
        static int menu()
        {
            int choice;
            Console.WriteLine("1. register yourself:");
            Console.WriteLine("2. login yourself:");
            Console.WriteLine("3. Exit:");
            Console.WriteLine("Enter your choice:");
            choice = int.Parse(Console.ReadLine());
            return choice;
        }
        static void signup(string path, string name, string pass)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(name + "," + pass);
            Console.WriteLine("registered succefully:");
            Console.ReadKey();
            file.Flush();
            file.Close();
        }
        static void signIn(string name, string pass, List<log> users)
        {
            bool flag = false;
            for(int idx = 0; idx<users.Count; idx++)
            {
                if(name == users[idx].username && pass == users[idx].password)
                {
                    flag = true;
                    break;
                }
            }
            if(flag == true)
            {
                Console.WriteLine("successfully:");
            }
            if(flag== false)
            {
                Console.WriteLine("invalid user:");
            }
            Console.ReadKey();
        }
        static string parsedata(string record, int field)
        {
            int comma = 1;
            string part = "";
            for(int idx = 0; idx<record.Length; idx++)
            {
                if(record[idx]==',')
                {
                    comma++;
                }
                else if(comma== field)
                {
                    part = part + record[idx];
                }
            }
            return part;
        }
        static void ReadData(string path, List<log> users)
        {
            if(File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while((record = file.ReadLine())!= null)
                {
                    log info = new log();
                    info.username = parsedata(record, 1);
                    info.password = parsedata(record, 2);
                    users.Add(info);
                }
                file.Close();
            }
            else
            {
                Console.WriteLine("NOT FOUND:");
            }
        }
    }
}
