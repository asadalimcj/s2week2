﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
    using System.IO;

namespace app
{
    public class admin
    {
        public string CityName;
        public string fare;
        public int Tseat;
        public string description = "Travel and Enjoy with us";
        public string contact = "03029614436";
        public string email = "faisalmovers@gmail.com";
        public int discount = 30;
    }
}
