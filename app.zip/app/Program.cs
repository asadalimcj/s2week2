﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace app
{
    class Program
    {
        static void Main(string[] args)
        {
            admin User = new admin();
            List<log> user = new List<log>();
            List<admin> changefare = new List<admin>();
            List<string> cityName = new List<string> {"sialkot", "zafarwal", "islamabad","faisalabad","lahore"};
            List<int> fares = new List<int> { 300, 400, 500, 600, 700 };
            string path = "D:\\uetlahore\\semester2\\OOP\\labs\\week2lab\\app\\path.txt";
            int choice = 0;
            while (choice != 3)
            {
                ReadData(path, user);
                Console.Clear();
                choice = menu();
                if (choice == 1)
                {
                    Console.WriteLine("enter your name:");
                    string name = Console.ReadLine();
                    Console.WriteLine("enter your passsword:");
                    string pass = Console.ReadLine();
                    signup(path, name, pass);
                }
                else if (choice == 2)
                {
                    Console.WriteLine("enter your name:");
                    string n = Console.ReadLine();
                    Console.WriteLine("enter password:");
                    string p = Console.ReadLine();
                    bool logIn = signIn(n, p, user);
                    if(logIn== true)
                    {
                        Console.WriteLine("log in successfully:");
                        Console.ReadKey();
                        Console.Clear();
                        TopHeader();
                        int num = AdminMenu();
                        if(num == 1)
                        {
                            Console.Clear();
                            TopHeader();
                            string Ncity;
                            Console.WriteLine("enter the name of city whose fare is to be updated:");
                            Ncity = Console.ReadLine();
                            SetFare(Ncity, cityName, fares);
                            Console.WriteLine("enter a key:");
                            for(int idx = 0; idx<fares.Count; idx++)
                            {
                                Console.WriteLine(fares[idx]);
                            }
                        }
                        if(num==2)
                        {
                            Console.Clear();
                            TopHeader();
                            Console.WriteLine("enter city name:");
                            string City = Console.ReadLine();
                            Console.WriteLine("enter number of seats:");
                            string seato = Console.ReadLine();
                            Console.WriteLine("enter the day:");
                            string day = Console.ReadLine();
                            int length = seato.ToString().Length;
                            int count = 0;
                            for (int idx = 0; idx < length; idx++)
                            {
                                int value = seato[idx] - '0';
                                if (value >= 0 && value < 10)
                                {
                                    count++;
                                }
                            }
                            if (count == length)
                            {
                                int result = BillPrep(City, seato, day, cityName, fares, changefare);
                                Console.WriteLine("this can be your bill {0}", result);
                                Console.WriteLine("enter a key");
                                Console.ReadKey();
                            }
                            else
                            {
                                Console.WriteLine("invalid entity!");
                                Console.WriteLine("press a key:");
                                Console.ReadKey();
                            }
                        }
                        if(num == 3)
                        {
                            Console.Clear();
                            TopHeader();
                            AdminAboutUs(User);
                            Console.WriteLine("enter a key:");
                            Console.ReadKey();
                        }
                        if(num==4)
                        {
                            Console.WriteLine("about us");
                        }
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("invalid entity:");
                        Console.ReadKey();
                    }
                }
                else
                {
                    break;
                }
            }
        }
        static int menu()
        {
            int choice;
            Console.WriteLine("1. register yourself:");
            Console.WriteLine("2. login yourself:");
            Console.WriteLine("3. Exit:");
            Console.WriteLine("Enter your choice:");
            choice = int.Parse(Console.ReadLine());
            return choice;
        }
        static void signup(string path, string name, string pass)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(name + "," + pass);
            Console.WriteLine("registered succefully:");
            Console.ReadKey();
            file.Flush();
            file.Close();
        }
        static bool signIn(string name, string pass, List<log> users)
        {
            bool flag = false;
            for (int idx = 0; idx < users.Count; idx++)
            {
                if (name == users[idx].username && pass == users[idx].password)
                {
                    flag = true;
                    break;
                }
            }
            return flag;
        }
        static string parsedata(string record, int field)
        {
            int comma = 1;
            string part = "";
            for (int idx = 0; idx < record.Length; idx++)
            {
                if (record[idx] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    part = part + record[idx];
                }
            }
            return part;
        }
        static void ReadData(string path, List<log> users)
        {
            if (File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                    log info = new log();
                    info.username = parsedata(record, 1);
                    info.password = parsedata(record, 2);
                    users.Add(info);
                }
                file.Close();
            }
            else
            {
                Console.WriteLine("NOT FOUND:");
            }
        }
        static void TopHeader()
        {
            Console.WriteLine("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
            Console.WriteLine(".....................................................");
            Console.WriteLine(".....................................................");
            Console.WriteLine(" ................FAISAL MOVERS.......................");
            Console.WriteLine(".....................................................");
            Console.WriteLine(".....................................................");
            Console.WriteLine("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
        }
        static int AdminMenu()
        {
            Console.Clear();
            TopHeader();
            Console.WriteLine("............ADMIN MENU..........");
            Console.WriteLine("1.SET FARES");
            Console.WriteLine("2. BILLS / DISCOUNT");
            Console.WriteLine("3. ABOUT US");
            Console.WriteLine("4.SEAT RECORD");
            Console.WriteLine("5.VIEW FEEDBACK");
            Console.WriteLine("6.VIEW USER STATUS");
            Console.WriteLine("7.EXIT");
            Console.WriteLine("ENTER YOUR CHOICE");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }
        static void SetFare(string city, List<string> location, List<int> fare)
        {
            int len = 0;
            int count = 0;
            int count1 = 0;
            int index = 0;
            string price = "";
            for(int idx = 0; idx<location.Count; idx++)
            {
                if(city == location[idx])
                {
                    index = idx;
                    count++;
                }
            }
            if(count==1)
            {
                Console.WriteLine("enter new price:");
                price = Console.ReadLine();
                len = price.ToString().Length;
                for(int idx = 0; idx<len; idx++)
                {
                    int value = price[idx] - '0';
                    if(value>=0 &&value<10)
                    {
                        count1++;
                    }
                }
            }
            if(count == 0)
            {
                Console.WriteLine("invalid location:");
                Console.ReadKey();
            }
            if(count1==len)
            {
                fare[index] = int.Parse(price);
                Console.WriteLine("fare updated:");
                Console.ReadKey();
            }
            if(count1==0)
            {
                Console.WriteLine("invalid entity");
                Console.ReadKey();
            }
        }
        static int BillPrep(string city, string seat, string day, List<string> location, List<int> fare, List<admin> dis)
        {
            int bill;
            int seatNum = int.Parse(seat);
            if ((day == "sunday" || day == "Sunday") || (day == "saturday" || day == "Saturday"))
            {
                for (int idx = 0; idx <location.Count; idx++)
                {
                    if (city == location[idx])
                    {
                        string temp = fare[idx].ToString();
                        int setPrice = int.Parse(temp);
                        bill = ((seatNum * setPrice) - (dis[0].discount* seatNum * setPrice) / 100);
                        return bill;
                    }
                }
            }
            else if ((day == "monday" || day == "Monday") || (day == "tuesday" || day == "Tuesday") || (day == "wednesday" || day == "Wednesday") || (day == "thursday" || day == "Thursday") || (day == "friday" || day == "Friday"))
            {
                for (int idx = 0; idx <location.Count; idx++)
                {
                    if (city == location[idx])
                    {
                        string temp = fare[idx].ToString();
                        int setPrice = int.Parse(temp);
                        bill = seatNum * setPrice;
                        return bill;
                    }
                }
            }
            else
            {
                Console.WriteLine("invalid day:");
                Console.WriteLine("enter a key:");
                Console.ReadKey();
            }
            return bill = 0;

        }
        static void UserAboutUs(admin user)
        {
            Console.WriteLine("ABOUT US :{0}", user.description);
            Console.WriteLine("CONTACT US AT: {0}",user.contact);
            Console.WriteLine("Email US :{0}", user.email);
        }
        static void AdminAboutUs(admin user)
        {
            char confirmation;
            
            Console.WriteLine("ABOUT US:{0}", user.description);
            Console.WriteLine("CONTACT US AT:{0}", user.contact);
            Console.WriteLine("Email:{0}", user.email);
            Console.WriteLine("Do you want to change ABOUT US? (y/n)");
            confirmation = char.Parse(Console.ReadLine());
            if(confirmation=='y' || confirmation == 'Y')
            {
                string E_mail;
                string Contact1;
                int Len;
                Console.WriteLine("ABOUT US:");
                user.description = Console.ReadLine();
                Console.WriteLine("CONTACT US  AT:");
                Contact1 = Console.ReadLine();
                Len = Contact1.Length;
                int count = 0;
                if(Len==11)
                {
                    for(int idx = 0; idx<Len; idx++)
                    {
                        int value = Contact1[idx] - '0';
                        if(value>=0 && value<10)
                        {
                            count++;
                        }
                    }
                    if(count==11)
                    {
                        user.contact = Contact1;
                        Console.WriteLine("CONTACT HAS BEEN UPDATED SUCCESSFULLY:");
                        Console.WriteLine("enter a key:");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Invalid phone number:");
                        Console.WriteLine("press a key:");
                        Console.ReadKey();
                    }
                }
                else
                {
                    Console.WriteLine("invalid phone number entered:");
                    Console.WriteLine("press a key:");
                    Console.ReadKey();
                }
                Console.WriteLine("ENTER EMAIL:");
                E_mail = Console.ReadLine();
                Len = E_mail.Length;
                int Count = 0;
                for(int idx = 0; idx<E_mail.Length; idx++)
                {
                    if(E_mail[idx] =='@')
                    {
                        Count++;
                    }
                }
                if(Count==1)
                {
                    user.email = E_mail;
                }
                else
                {
                    Console.WriteLine("invalid email entered");
                    Console.WriteLine("press a key:");
                    Console.ReadKey();
                }
                UserAboutUs(user);
            }
        }
    }
}
